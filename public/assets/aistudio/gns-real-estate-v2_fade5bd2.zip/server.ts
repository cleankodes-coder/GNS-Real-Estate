import http from 'http';
import express from 'express';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = parseInt(process.env.PORT || '3000', 10);

// Initialize Gemini client with standard telemetry User-Agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const TEXT_CHAT_SYSTEM_INSTRUCTION =
  "You are the GNS AI Receptionist for GNS Real Estate, Dubai.\n" +
  "You are a warm, friendly young woman working as a receptionist. Speak naturally and conversationally, like a real person on a phone call. Use short sentences, a calm pace, and a polite, welcoming tone. Avoid sounding robotic or reading like a script.\n" +
  "Greeting is already done. Do not repeat it. Directly answer the user's latest question.\n" +
  "Keep replies short (1 to 3 sentences) so the conversation feels natural.\n" +
  "Ask only one follow-up question at a time.\n" +
  "Reply in the same language the user speaks (English, Urdu or Hindi).";

// System instruction for Gemini Live Phone Call
const LIVE_SYSTEM_INSTRUCTION =
  "You are Sara, a warm, friendly, professional female receptionist at GNS Real Estate, Dubai, on a LIVE PHONE CALL. Speak naturally like a real person: short sentences, calm pace, polite tone, small natural phrases like 'sure' and 'of course'. Keep each reply to 1 to 3 sentences and ask only one question at a time. Greet the caller once at the start only. Answer the caller's latest question directly. Reply in the language the caller speaks (English, Urdu or Hindi). Never say this is a text chat. Never promise things you cannot do, such as emailing brochures or having an agent call back. If the caller wants a human, tell them to use the WhatsApp Advisor button. Do not make up property details.";

// Synthesize speech using Gemini native TTS with female prebuilt voice (Aoede, fallback Kore)
async function generateGeminiSpeech(text: string): Promise<string> {
  const voices = ['Aoede', 'Kore'];
  let lastErr: any = null;

  for (const voiceName of voices) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text,
                speechMetadata: {
                  style: 'Warm, friendly young woman working as a receptionist on a phone call. Natural, conversational, calm pace, polite and welcoming tone.',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        return base64Audio;
      }
    } catch (err: any) {
      console.warn(`TTS with voice ${voiceName} failed:`, err?.message || err);
      lastErr = err;
    }
  }

  throw lastErr || new Error('Gemini TTS generation failed');
}

// Standalone endpoint for Text-to-Speech synthesis
app.post('/api/tts', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Text string is required for speech synthesis.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is missing from environment.' });
    }

    const audioBase64 = await generateGeminiSpeech(text.trim());
    return res.json({ audioBase64 });
  } catch (error: any) {
    console.error('API /api/tts error:', error);
    return res.status(500).json({ error: error?.message || 'Internal error during Gemini speech synthesis.' });
  }
});

// API route for text chat
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history, generateAudio } = req.body;

    if (!message && (!Array.isArray(history) || history.length === 0)) {
      return res.status(400).json({ error: 'Message or conversation history is required.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is missing from environment.' });
    }

    const rawItems: Array<{ role: 'user' | 'model'; text: string }> = [];

    if (Array.isArray(history)) {
      for (const item of history) {
        if (!item || !item.text || typeof item.text !== 'string') continue;
        const role = item.sender === 'user' ? 'user' : 'model';
        rawItems.push({ role, text: item.text.trim() });
      }
    }

    if (message && typeof message === 'string' && message.trim().length > 0) {
      const trimmedMsg = message.trim();
      if (rawItems.length === 0 || rawItems[rawItems.length - 1].text !== trimmedMsg) {
        rawItems.push({ role: 'user', text: trimmedMsg });
      }
    }

    if (rawItems.length === 0) {
      return res.status(400).json({ error: 'No valid message content provided.' });
    }

    const formattedContents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    for (const item of rawItems) {
      if (formattedContents.length > 0 && formattedContents[formattedContents.length - 1].role === item.role) {
        formattedContents[formattedContents.length - 1].parts[0].text += `\n${item.text}`;
      } else {
        formattedContents.push({
          role: item.role,
          parts: [{ text: item.text }],
        });
      }
    }

    while (formattedContents.length > 0 && formattedContents[0].role !== 'user') {
      formattedContents.shift();
    }

    if (formattedContents.length === 0) {
      formattedContents.push({
        role: 'user',
        parts: [{ text: message || 'Hello' }],
      });
    }

    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
    let lastError: any = null;
    let replyText = '';

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: formattedContents,
          config: {
            systemInstruction: TEXT_CHAT_SYSTEM_INSTRUCTION,
          },
        });

        if (response && response.text) {
          replyText = response.text;
          break;
        }
      } catch (err: any) {
        console.warn(`Model ${modelName} failed or busy:`, err?.message || err);
        lastError = err;
      }
    }

    if (!replyText) {
      const errMsg = lastError?.message || lastError?.toString() || 'Failed to generate response from Gemini API';
      return res.status(500).json({ error: errMsg });
    }

    let audioBase64: string | undefined;
    if (generateAudio) {
      try {
        audioBase64 = await generateGeminiSpeech(replyText);
      } catch (audioErr: any) {
        console.warn('Speech synthesis for reply failed:', audioErr?.message || audioErr);
      }
    }

    return res.json({ text: replyText, audioBase64 });
  } catch (error: any) {
    console.error('API /api/chat error:', error);
    return res.status(500).json({ error: error?.message || 'Internal server error while calling Gemini API' });
  }
});

// Helper to connect to Gemini Live with native audio model and female voice Aoede / Kore
async function establishGeminiLiveSession(onMessage: (msg: any) => void, onClose: (e?: any) => void) {
  const models = ['gemini-3.8-live', 'gemini-2.5-flash-native-audio-preview'];
  const voices = ['Aoede', 'Kore'];

  let lastError: any = null;

  for (const model of models) {
    for (const voiceName of voices) {
      try {
        let isRejected = false;
        const session = await ai.live.connect({
          model,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName } },
            },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: LIVE_SYSTEM_INSTRUCTION,
          },
          callbacks: {
            onmessage: onMessage,
            onclose: (e) => {
              if (e?.code === 1008 || e?.reason?.includes('not found')) {
                isRejected = true;
              }
              onClose(e);
            },
            onerror: (err) => {
              console.warn(`Gemini Live session error (${model}, ${voiceName}):`, err?.message || err);
            },
          },
        });

        // Give a brief tick to detect immediate 1008 close frame
        await new Promise((r) => setTimeout(r, 150));
        if (isRejected) {
          continue;
        }

        return session;
      } catch (err: any) {
        lastError = err;
        console.warn(`Gemini Live connect attempt failed (${model}, ${voiceName}):`, err?.message || err);
      }
    }
  }

  throw lastError || new Error('Could not establish Gemini Live session');
}

// Mount Vite middleware in development or serve static build in production
async function startServer() {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '', `http://${request.headers.host}`).pathname;
    if (pathname === '/api/live') {
      wss.handleUpgrade(request, socket, head, (clientWs) => {
        wss.emit('connection', clientWs, request);
      });
    }
  });

  wss.on('connection', async (clientWs: WebSocket) => {
    let session: any = null;
    let isClosed = false;

    const safeSend = (payload: any) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify(payload));
      }
    };

    try {
      if (!process.env.GEMINI_API_KEY) {
        safeSend({ type: 'error', error: 'GEMINI_API_KEY is not configured on server.' });
        clientWs.close();
        return;
      }

      session = await establishGeminiLiveSession(
        (msg: any) => {
          if (isClosed) return;

          const content = msg.serverContent;
          if (!content) return;

          // Model spoken audio chunks (24kHz PCM little-endian)
          if (content.modelTurn?.parts) {
            for (const part of content.modelTurn.parts) {
              if (part.inlineData?.data) {
                safeSend({ type: 'audio', audio: part.inlineData.data });
              }
            }
          }

          // Live transcript of Sara's speech
          if (content.outputTranscription?.text) {
            safeSend({ type: 'outputTranscript', text: content.outputTranscription.text });
          }

          // Live transcript of the caller's speech
          if (content.inputTranscription?.text) {
            safeSend({ type: 'inputTranscript', text: content.inputTranscription.text });
          }

          // Automatic VAD interruption: caller started speaking while Sara was talking
          if (content.interrupted) {
            safeSend({ type: 'interrupted' });
          }

          // Model finished current speech turn
          if (content.turnComplete) {
            safeSend({ type: 'turnComplete' });
          }
        },
        (closeEvent?: any) => {
          if (!isClosed) {
            safeSend({ type: 'closed', reason: closeEvent?.reason || 'Session closed' });
          }
        }
      );

      safeSend({ type: 'connected' });

      clientWs.on('message', async (data) => {
        if (isClosed || !session) return;
        try {
          const parsed = JSON.parse(data.toString());

          if (parsed.type === 'start') {
            // Trigger Sara's initial call greeting
            await session.sendRealtimeInput({
              text: 'Start the call with your warm phone greeting now.',
            });
          } else if (parsed.type === 'audio' && parsed.audio) {
            // Stream incoming 16kHz PCM audio chunk from caller microphone
            await session.sendRealtimeInput({
              audio: { data: parsed.audio, mimeType: 'audio/pcm;rate=16000' },
            });
          }
        } catch (err: any) {
          console.warn('Error processing client message:', err?.message || err);
        }
      });

      clientWs.on('close', async () => {
        isClosed = true;
        if (session) {
          try {
            await session.close();
          } catch {}
          session = null;
        }
      });

      clientWs.on('error', (err) => {
        console.warn('Client WebSocket error:', err);
      });
    } catch (err: any) {
      console.error('Failed to initiate Gemini Live session:', err);
      safeSend({ type: 'error', error: err?.message || 'Failed to connect to Gemini Live session' });
      clientWs.close();
    }
  });

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('index.html', { root: 'dist' });
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`GNS Real Estate full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
