import React, { useState, useRef, useEffect, useCallback } from 'react';
import { MessageSquare, X, Send, Bot, PhoneCall, PhoneOff, Mic, MicOff, Volume2, Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { GNS_CONFIG, VERIFIED_PROPERTIES } from '../data/gnsData';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedSlug?: string;
  isVoiceTranscript?: boolean;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-init',
    sender: 'assistant',
    text: 'Hello, welcome to GNS Real Estate. I am the GNS AI Receptionist. Are you looking to buy a home, invest in an off-plan project, or explore specific Dubai communities?',
    timestamp: 'Just now',
  },
];

const SUGGESTED_QUERIES = [
  'What off-plan projects are available?',
  'Tell me about Oria by Emaar',
  'Villas in Dubai Hills Estate',
  'What is the starting price for Bayz 102?',
];

// System instruction for Gemini AI Assistant and Voice
export const SYSTEM_INSTRUCTION =
  "You are the GNS AI Receptionist for GNS Real Estate, Dubai.\n" +
  "You are a warm, friendly young woman working as a receptionist. Speak naturally and conversationally, like a real person on a phone call. Use short sentences, a calm pace, and a polite, welcoming tone. Avoid sounding robotic or reading like a script.\n" +
  "Greeting is already done. Do not repeat it. Directly answer the user's latest question.\n" +
  "Keep replies short (1 to 3 sentences) so the conversation feels natural.\n" +
  "Ask only one follow-up question at a time.\n" +
  "Reply in the same language the user speaks (English, Urdu or Hindi).";

/**
 * Calls Gemini AI backend endpoint with full conversation history and optional native TTS generation.
 * If the API call fails, throws an Error containing the actual error message.
 */
export async function fetchGeminiChatReply(
  query: string,
  history: ChatMessage[],
  generateAudio = false
): Promise<{ text: string; audioBase64?: string }> {
  const payload = {
    message: query,
    history: history.map((m) => ({
      sender: m.sender,
      text: m.text,
    })),
    generateAudio,
  };

  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    const errText = errorData?.error || `Gemini API request failed with status ${response.status}`;
    throw new Error(errText);
  }

  const data = await response.json();
  if (!data || typeof data.text !== 'string') {
    throw new Error('Received empty or invalid reply from Gemini API');
  }

  return { text: data.text.trim(), audioBase64: data.audioBase64 };
}

/**
 * Synthesize speech using Gemini native TTS with female prebuilt voice (Aoede / Kore)
 */
export async function fetchGeminiTTS(text: string): Promise<string> {
  const response = await fetch('/api/tts', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    throw new Error(errorData?.error || `TTS request failed with status ${response.status}`);
  }

  const data = await response.json();
  if (!data || typeof data.audioBase64 !== 'string') {
    throw new Error('Received invalid audio data from Gemini TTS');
  }

  return data.audioBase64;
}

export const AskGNSWidget: React.FC<{ onOpenViewingModal?: (title?: string, id?: string) => void }> = ({
  onOpenViewingModal,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [isTyping, setIsTyping] = useState(false);

  // Gemini Live Voice Call State
  const [isCallActive, setIsCallActive] = useState(false);
  const [callStatus, setCallStatus] = useState<'idle' | 'connecting' | 'listening' | 'speaking' | 'muted' | 'error'>('idle');
  const [callErrorMessage, setCallErrorMessage] = useState('');
  const [isMuted, setIsMuted] = useState(false);

  // References for Live Audio Streaming and WebSockets
  const isCallActiveRef = useRef(false);
  const isMutedRef = useRef(false);
  const messagesRef = useRef<ChatMessage[]>(messages);
  const wsRef = useRef<WebSocket | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const audioProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourceNodesRef = useRef<AudioBufferSourceNode[]>([]);
  const currentCallerMsgIdRef = useRef<string | null>(null);
  const currentSaraMsgIdRef = useRef<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Keep messagesRef in sync with current messages state
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  /**
   * Stop all currently scheduled and playing audio buffer sources immediately (for interruption or hang up)
   */
  const stopAllPlayback = useCallback(() => {
    activeSourceNodesRef.current.forEach((src) => {
      try {
        src.stop();
        src.disconnect();
      } catch {}
    });
    activeSourceNodesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  }, []);

  /**
   * Play incoming 24kHz PCM audio chunk smoothly as a gapless continuous stream
   */
  const playAudioChunk = useCallback((base64Data: string) => {
    if (!outputAudioCtxRef.current) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      outputAudioCtxRef.current = new AudioCtxClass({ sampleRate: 24000 });
    }

    const ctx = outputAudioCtxRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    try {
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const int16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / (int16[i] < 0 ? 0x8000 : 0x7fff);
      }

      if (float32.length === 0) return;

      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.copyToChannel(float32, 0);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      // Precision scheduling for seamless, gap-free playback
      const now = ctx.currentTime;
      if (nextStartTimeRef.current < now) {
        nextStartTimeRef.current = now + 0.04;
      }

      source.start(nextStartTimeRef.current);
      nextStartTimeRef.current += audioBuffer.duration;

      activeSourceNodesRef.current.push(source);
      setCallStatus('speaking');

      source.onended = () => {
        const list = activeSourceNodesRef.current;
        const idx = list.indexOf(source);
        if (idx !== -1) list.splice(idx, 1);
        if (
          list.length === 0 &&
          outputAudioCtxRef.current &&
          outputAudioCtxRef.current.currentTime >= nextStartTimeRef.current - 0.06
        ) {
          if (isCallActiveRef.current && !isMutedRef.current) {
            setCallStatus('listening');
          }
        }
      };
    } catch (err) {
      console.warn('Error queuing audio buffer chunk:', err);
    }
  }, []);

  /**
   * Resamples / converts Float32Array input to 16-bit 16kHz PCM little endian
   */
  const processInputAudioTo16k = (inputBuffer: Float32Array, inputSampleRate: number): string => {
    let int16Array: Int16Array;

    if (inputSampleRate === 16000) {
      int16Array = new Int16Array(inputBuffer.length);
      for (let i = 0; i < inputBuffer.length; i++) {
        const s = Math.max(-1, Math.min(1, inputBuffer[i]));
        int16Array[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
    } else {
      const ratio = inputSampleRate / 16000;
      const newLength = Math.round(inputBuffer.length / ratio);
      int16Array = new Int16Array(newLength);
      let offsetResult = 0;
      let offsetBuffer = 0;

      while (offsetResult < int16Array.length) {
        const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
        let accum = 0;
        let count = 0;
        for (let i = offsetBuffer; i < nextOffsetBuffer && i < inputBuffer.length; i++) {
          accum += inputBuffer[i];
          count++;
        }
        const sample = count > 0 ? accum / count : 0;
        const s = Math.max(-1, Math.min(1, sample));
        int16Array[offsetResult] = s < 0 ? s * 0x8000 : s * 0x7fff;
        offsetResult++;
        offsetBuffer = nextOffsetBuffer;
      }
    }

    let binary = '';
    const bytes = new Uint8Array(int16Array.buffer, int16Array.byteOffset, int16Array.byteLength);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };

  /**
   * End voice call cleanly and reset all audio/WebSocket handles
   */
  const endVoiceCall = useCallback(() => {
    setIsCallActive(false);
    isCallActiveRef.current = false;
    setCallStatus('idle');

    stopAllPlayback();

    currentCallerMsgIdRef.current = null;
    currentSaraMsgIdRef.current = null;

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {}
      wsRef.current = null;
    }

    if (audioProcessorRef.current) {
      try {
        audioProcessorRef.current.disconnect();
      } catch {}
      audioProcessorRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch {}
      inputAudioCtxRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      try {
        outputAudioCtxRef.current.close();
      } catch {}
      outputAudioCtxRef.current = null;
    }
  }, [stopAllPlayback]);

  // Clean up on component unmount
  useEffect(() => {
    return () => {
      endVoiceCall();
    };
  }, [endVoiceCall]);

  /**
   * Start a Live two-way phone call with Sara using Gemini Live API
   */
  const startVoiceCall = async () => {
    endVoiceCall();
    setCallErrorMessage('');
    setCallStatus('connecting');
    setIsCallActive(true);
    isCallActiveRef.current = true;
    currentCallerMsgIdRef.current = null;
    currentSaraMsgIdRef.current = null;

    try {
      // 1. Capture microphone with echo cancellation, noise suppression & auto gain control
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });
      mediaStreamRef.current = stream;

      // 2. Initialize playback and input AudioContexts
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioCtxClass();
      inputAudioCtxRef.current = inputCtx;

      const outputCtx = new AudioCtxClass({ sampleRate: 24000 });
      outputAudioCtxRef.current = outputCtx;
      nextStartTimeRef.current = outputCtx.currentTime;

      // 3. Connect WebSocket bridge to Gemini Live on server
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        // Connected to server bridge
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'connected') {
            setCallStatus('listening');
            // Trigger Sara's initial call greeting
            ws.send(JSON.stringify({ type: 'start' }));
          } else if (msg.type === 'audio' && msg.audio) {
            // Smooth gapless playback of Sara's voice
            playAudioChunk(msg.audio);
          } else if (msg.type === 'outputTranscript' && msg.text) {
            // Live transcript of Sara's speech updated in chat
            const chunk = msg.text;
            if (!currentSaraMsgIdRef.current) {
              const newId = `sara-${Date.now()}`;
              currentSaraMsgIdRef.current = newId;
              const newMsg: ChatMessage = {
                id: newId,
                sender: 'assistant',
                text: chunk,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              };
              setMessages((prev) => [...prev, newMsg]);
            } else {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === currentSaraMsgIdRef.current
                    ? { ...m, text: m.text + chunk }
                    : m
                )
              );
            }
          } else if (msg.type === 'inputTranscript' && msg.text) {
            // Live transcript of caller's speech updated in chat
            currentSaraMsgIdRef.current = null;
            const callerText = msg.text.trim();
            if (!callerText) return;

            if (!currentCallerMsgIdRef.current) {
              const newId = `caller-${Date.now()}`;
              currentCallerMsgIdRef.current = newId;
              const newMsg: ChatMessage = {
                id: newId,
                sender: 'user',
                text: callerText,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                isVoiceTranscript: true,
              };
              setMessages((prev) => [...prev, newMsg]);
            } else {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === currentCallerMsgIdRef.current
                    ? { ...m, text: m.text + ' ' + callerText }
                    : m
                )
              );
            }
          } else if (msg.type === 'interrupted') {
            // Caller spoke: stop playback immediately and listen
            stopAllPlayback();
            setCallStatus('listening');
            currentSaraMsgIdRef.current = null;
          } else if (msg.type === 'turnComplete') {
            currentCallerMsgIdRef.current = null;
            currentSaraMsgIdRef.current = null;
          } else if (msg.type === 'error') {
            const errStr = msg.error || 'Gemini Live encountered an error';
            setCallErrorMessage(errStr);
            setCallStatus('error');
            const errChatMessage: ChatMessage = {
              id: `err-${Date.now()}`,
              sender: 'assistant',
              text: `Call Error: ${errStr}`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
            setMessages((prev) => [...prev, errChatMessage]);
          } else if (msg.type === 'closed') {
            if (isCallActiveRef.current) {
              endVoiceCall();
            }
          }
        } catch (err) {
          console.warn('Error handling WebSocket message:', err);
        }
      };

      ws.onerror = () => {
        setCallErrorMessage('WebSocket connection failed to reach Gemini Live server.');
        setCallStatus('error');
      };

      ws.onclose = () => {
        if (isCallActiveRef.current) {
          endVoiceCall();
        }
      };

      // 4. Hook microphone audio processor to stream 16kHz PCM chunks
      const micSource = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(2048, 1, 1);
      audioProcessorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (!isCallActiveRef.current || isMutedRef.current) return;
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

        const inputData = e.inputBuffer.getChannelData(0);
        const pcmBase64 = processInputAudioTo16k(inputData, inputCtx.sampleRate);

        wsRef.current.send(
          JSON.stringify({
            type: 'audio',
            audio: pcmBase64,
          })
        );
      };

      micSource.connect(processor);
      processor.connect(inputCtx.destination);
    } catch (err: any) {
      console.error('Call initialization failure:', err);
      const msg = err?.message || 'Could not access microphone or initiate call.';
      setCallErrorMessage(msg);
      setCallStatus('error');
      setIsCallActive(false);
      isCallActiveRef.current = false;
    }
  };

  /**
   * Toggle Mute on/off during an active call.
   */
  const toggleMute = () => {
    if (!isCallActiveRef.current) return;

    if (isMutedRef.current) {
      setIsMuted(false);
      isMutedRef.current = false;
      setCallStatus('listening');
    } else {
      setIsMuted(true);
      isMutedRef.current = true;
      setCallStatus('muted');
      stopAllPlayback();
    }
  };

  /**
   * Handler for text chat input (remains completely supported and unchanged)
   */
  const handleUserMessage = useCallback(
    async (textToSend?: string) => {
      const text = (textToSend || inputMessage).trim();
      if (!text) return;

      const userMsg: ChatMessage = {
        id: `user-${Date.now()}`,
        sender: 'user',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const updatedHistory = [...messagesRef.current, userMsg];
      messagesRef.current = updatedHistory;
      setMessages(updatedHistory);
      setInputMessage('');
      setIsTyping(true);

      try {
        const { text: answerText } = await fetchGeminiChatReply(text, updatedHistory, false);

        const matchedProp = VERIFIED_PROPERTIES.find((p) => {
          const title = p.title.toLowerCase();
          const combined = (text + ' ' + answerText).toLowerCase();
          return combined.includes(title) || (p.slug && combined.includes(p.slug.replace(/-/g, ' ')));
        });

        const assistantMsg: ChatMessage = {
          id: `asst-${Date.now()}`,
          sender: 'assistant',
          text: answerText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedSlug: matchedProp?.slug,
        };

        const finalHistory = [...updatedHistory, assistantMsg];
        messagesRef.current = finalHistory;
        setMessages(finalHistory);
      } catch (err: any) {
        const actualError = err?.message || 'Failed to communicate with Gemini API';
        const errorMsg: ChatMessage = {
          id: `asst-${Date.now()}`,
          sender: 'assistant',
          text: `Error: ${actualError}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        const finalHistory = [...updatedHistory, errorMsg];
        messagesRef.current = finalHistory;
        setMessages(finalHistory);
      } finally {
        setIsTyping(false);
      }
    },
    [inputMessage]
  );

  return (
    <div className="fixed bottom-6 right-6 z-40 select-none">
      {/* Compact gold-accented launcher button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          type="button"
          aria-label="Open GNS AI Receptionist"
          className="group flex items-center gap-2.5 bg-[#202020] hover:bg-[#D6A536] text-white hover:text-[#202020] px-4 py-3 rounded-full shadow-xl border border-[#E8E5DE] transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D6A536]"
        >
          <div className="w-6 h-6 rounded-full bg-[#D6A536] text-[#202020] group-hover:bg-[#202020] group-hover:text-[#D6A536] flex items-center justify-center transition-colors">
            <Bot className="w-3.5 h-3.5" />
          </div>
          <div className="text-left hidden sm:block">
            <span className="block text-[10px] tracking-wider uppercase font-semibold text-[#D6A536] group-hover:text-[#202020]">
              AI Receptionist
            </span>
            <span className="block text-xs font-semibold leading-tight">
              Ask GNS
            </span>
          </div>
        </button>
      )}

      {/* Assistant Modal Panel (101 Style: Inter, gold accents, clean borders) */}
      {isOpen && (
        <div
          role="dialog"
          aria-labelledby="assistant-panel-title"
          className="w-[340px] sm:w-[390px] h-[520px] bg-white border border-[#E8E5DE] rounded-lg shadow-2xl flex flex-col overflow-hidden animate-in fade-in duration-200"
        >
          {/* Header */}
          <div className="bg-[#202020] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#D6A536] rounded-md flex items-center justify-center text-[#202020]">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 id="assistant-panel-title" className="font-serif text-sm font-semibold leading-none">
                  GNS AI Receptionist
                </h3>
                <span className="text-[10px] tracking-wider text-[#D6A536] uppercase font-semibold">
                  English & Urdu / Hindi
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Call Start/End Toggle */}
              {!isCallActive ? (
                <button
                  type="button"
                  onClick={startVoiceCall}
                  className="flex items-center gap-1 bg-[#D6A536] hover:bg-[#B98722] text-[#202020] text-[10px] font-semibold px-2.5 py-1 rounded-sm uppercase tracking-wider transition-colors shadow-2xs"
                  title="Start Voice Call"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Call</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={endVoiceCall}
                  className="flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white text-[10px] font-semibold px-2.5 py-1 rounded-sm uppercase tracking-wider transition-colors"
                  title="End Voice Call"
                >
                  <PhoneOff className="w-3 h-3" />
                  <span>End</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  endVoiceCall();
                  setIsOpen(false);
                }}
                aria-label="Close Assistant"
                className="p-1.5 text-white/70 hover:text-white rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Voice Call Active Status Banner */}
          {isCallActive && (
            <div className="bg-[#F5F4F0] border-b border-[#E8E5DE] px-4 py-2 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    callStatus === 'listening'
                      ? 'bg-emerald-500 animate-ping'
                      : callStatus === 'speaking'
                      ? 'bg-[#D6A536] animate-pulse'
                      : callStatus === 'muted'
                      ? 'bg-amber-500'
                      : 'bg-red-500'
                  }`}
                />
                <span className="font-semibold text-[#202020]">
                  {callStatus === 'listening'
                    ? 'Listening'
                    : callStatus === 'speaking'
                    ? 'Sara is speaking'
                    : callStatus === 'muted'
                    ? 'Microphone muted'
                    : callStatus === 'connecting'
                    ? 'Connecting'
                    : 'Call Standby'}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={toggleMute}
                  className={`p-1 rounded-sm border ${
                    isMuted ? 'bg-amber-100 border-amber-300 text-amber-800' : 'bg-white border-[#E8E5DE] text-[#202020]'
                  }`}
                  title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
                >
                  {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}

          {callErrorMessage && (
            <div className="bg-red-50 text-red-700 px-3 py-1.5 text-[11px] border-b border-red-200">
              {callErrorMessage}
            </div>
          )}

          {/* Chat Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-[#F5F4F0]">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3 rounded-lg leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#202020] text-white shadow-2xs'
                      : 'bg-white text-[#202020] border border-[#E8E5DE] shadow-2xs'
                  }`}
                >
                  <p>{msg.text}</p>
                  {msg.suggestedSlug && (
                    <div className="mt-2.5 pt-2 border-t border-[#E8E5DE]">
                      <Link
                        to={`/properties/${msg.suggestedSlug}`}
                        onClick={() => setIsOpen(false)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#D6A536] hover:text-[#B98722]"
                      >
                        <span>View Property Dossier</span>
                        <ArrowRight className="w-3 h-3" />
                      </Link>
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-[#666666] mt-1 px-1">{msg.timestamp}</span>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 text-[11px] text-[#666666] p-2 bg-white border border-[#E8E5DE] rounded-md w-fit">
                <Sparkles className="w-3 h-3 text-[#D6A536] animate-spin" />
                <span>Checking verified inventory...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts */}
          <div className="px-3 py-2 bg-white border-t border-[#E8E5DE] overflow-x-auto whitespace-nowrap flex gap-1.5">
            {SUGGESTED_QUERIES.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleUserMessage(q)}
                className="px-2.5 py-1 text-[10.5px] bg-[#F5F4F0] hover:bg-[#E8E5DE] text-[#202020] border border-[#E8E5DE] rounded-sm shrink-0 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleUserMessage();
            }}
            className="p-3 bg-white border-t border-[#E8E5DE] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask about properties, pricing, areas, or in Urdu..."
              className="flex-1 bg-[#F5F4F0] border border-[#E8E5DE] rounded-md px-3 py-2 text-xs text-[#202020] placeholder:text-[#666666] focus:outline-none focus:border-[#D6A536]"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              aria-label="Send message"
              className="bg-[#D6A536] hover:bg-[#B98722] disabled:opacity-40 text-[#202020] p-2 rounded-md transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Footer Action */}
          <div className="bg-[#202020] py-2 px-3 text-[10.5px] text-white flex items-center justify-between">
            <span className="text-[#E8E5DE]">Direct Human Desk:</span>
            <a
              href={`https://wa.me/${GNS_CONFIG.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#D6A536] font-semibold hover:underline"
            >
              WhatsApp Advisor
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
